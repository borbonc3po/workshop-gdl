package com.recluit.lab.restservices;

import java.util.ArrayList;
import java.util.List;

public class BookStore 
{
	private List<Book> allBooks;
	
	//Simulating a DB
	
	public BookStore()
	{
		allBooks = new ArrayList<Book>();
		allBooks.add(new Book("Sherlock Holmes","Sir Arthur Conan"));
		allBooks.add(new Book("Hobbit","JRR Tolkien"));
	}

	public List<Book> getAllBooks() {
		return allBooks;
	}

	public void setAllBooks(List<Book> allBooks) {
		this.allBooks = allBooks;
	}
	
}
