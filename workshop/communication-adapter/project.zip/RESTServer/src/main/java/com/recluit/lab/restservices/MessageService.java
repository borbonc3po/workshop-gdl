package com.recluit.lab.restservices;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

//import com.recluit.lab.action.Book;
//import com.recluit.lab.action.BookStore;
//import com.recluit.lab.restclient.HelloClient;

@Path("/book")
public class MessageService 
{
	/*Quitar el string como parametro 
	 * y regresar un solo libro
	 */
	@GET
	@Path("/{title}")
	@Produces(MediaType.TEXT_PLAIN)
	public String sayHello(@PathParam("title") String title)
	{
		System.out.println("Book ti query: "+title);
		BookStore bookStore;
		String bookResultAuthor;
		String bookResultTitle;
		bookStore = new BookStore();
		for (Book book : bookStore.getAllBooks())
		{
			if(book.getTitle().equals(title))
			{
			
				bookResultTitle = book.getTitle();
				bookResultAuthor = book.getAuthor();
				return bookResultAuthor + "," + bookResultTitle;
			}
		}
		
		return "ERROR";
	}
	
	@GET
	@Produces(MediaType.TEXT_XML)
	public String sayXMLHello()
	{
		return "<?xml version=\"1.0\"?>"+
				"<hello>Hello from RESTServer!!!!!!!</hello>";
	}
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String sayHtmlHello()
	{
		return new StringBuilder("")
		.append("<html>")
		.append("\t<head><title>Hello</title></head>")
		.append("\t<body><h1>Hello from the server</h1></body>")
		.append("</html>").toString();
		
	}
	

}
